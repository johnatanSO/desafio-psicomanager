type Props = {
  text?: string
}
export function Empty({ text }: Props) {
  return (
    <div>
      <p>{text || 'Nenhum item encontrado'}</p>
    </div>
  )
}
