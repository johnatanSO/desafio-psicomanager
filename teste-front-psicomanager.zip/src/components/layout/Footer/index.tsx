export function Footer() {
  return <footer>footer</footer>
}
