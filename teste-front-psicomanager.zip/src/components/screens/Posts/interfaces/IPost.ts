export interface IPost {
  id: string
}
