'use client'

import { useEffect, useState } from 'react'
import { IPost } from './interfaces/IPost'
import { Post } from './Post'
import { Empty } from '@/components/_ui/Empty'
import { listPostsService } from '@/components/services/posts/listPosts/listPostsService'

export function Posts() {
  const [posts, setPosts] = useState<IPost[]>([])

  function getPosts() {
    listPostsService()
      .then((res) => {
        setPosts(res.data)
      })
      .catch((err) => {
        console.error(err)
      })
  }

  useEffect(() => {
    getPosts()
  }, [])

  return (
    <>
      {posts.length === 0 && <Empty text="Nenhum post encontrado" />}

      {posts.length > 0 &&
        posts.map((post) => {
          return <Post key={post.id} />
        })}
    </>
  )
}
