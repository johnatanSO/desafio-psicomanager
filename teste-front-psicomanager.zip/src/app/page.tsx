import { Posts } from "@/components/screens/Posts";

export default function Home() {
  return (
    <>
      <Posts />
    </>
  );
}
